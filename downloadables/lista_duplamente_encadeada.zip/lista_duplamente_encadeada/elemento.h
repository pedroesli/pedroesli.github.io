#ifndef ELEMENTO_H
#define ELEMENTO_H

#include "cidade.h"

typedef struct elemento {
	Cidade city;
	struct elemento *prox;
	struct elemento *ant;
}Elem;

Elem *alocar_elem(void);

#endif

#ifndef DESCRITOR_H
#define DESCRITOR_H

#include "cidade.h"
#include "elemento.h"

typedef struct descritor {
	Elem *inicio;
	Elem *fim;
	int qtde;
}Descritor;

Descritor criar_lista( void );
int inserir_cidade( Descritor *, Cidade );
int remover_cidade( Descritor *, int );
int lista_vazia( Descritor * );
int tamanho_lista( Descritor * );
int imprimir_lista( Descritor * );
void destruir_lista( Descritor * );

#endif

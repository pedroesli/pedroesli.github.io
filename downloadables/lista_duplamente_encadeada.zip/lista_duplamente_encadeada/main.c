#include <stdio.h>
#include <stdlib.h>

#include "descritor.h"


int main() {
	Descritor lista;
	Cidade novo;
	int i;
	lista = criar_lista();

	for(i = 0;i<3;i++){
		novo = ler_cidade();
		inserir_cidade(&lista,novo);	
	}
	
	printf("%i\n",remover_cidade(&lista,4));
	imprimir_lista(&lista);
	destruir_lista(&lista);
	return 0;
}

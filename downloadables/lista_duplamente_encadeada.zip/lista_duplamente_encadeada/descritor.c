#include <stdlib.h>
#include <stdio.h>

#include "descritor.h"


Descritor criar_lista( void ){
	Descritor lista;
	lista.inicio = NULL;
	lista.fim = NULL;
	lista.qtde = 0;
	return lista;
}
int inserir_cidade( Descritor *lst, Cidade novo){
	Elem *no,*p;
	if(!(no = alocar_elem()))
		return 0;
	no->city = novo;
	no->ant = NULL;
	no->prox = NULL;
	
	if((*lst).qtde == 0){
		(*lst).inicio = no;
		(*lst).fim = no;
		(*lst).qtde++;
	}
	else{
		if(no->city.id < (*lst).inicio->city.id){
			(*lst).inicio->ant = no;
			no->prox = (*lst).inicio;
			(*lst).inicio = no;
		}
		else if(no->city.id > (*lst).fim->city.id){
			(*lst).fim->prox = no;
			no->ant = (*lst).fim;
			(*lst).fim = no;
		}
		else{
			p = (*lst).inicio;
			while(no->city.id > p->prox->city.id)
				p = p->prox;
			no->prox = p->prox;
			p->prox->ant = no;
			
			no->ant = p;
			p->prox = no;
		}
		
	}
	return 1;
}
// 1 = removeu com sucesso , 0 = lista vazia , -1 = n�o encontrou
int remover_cidade( Descritor *lst, int id){
	Elem *p;
	if((*lst).qtde == 0)
		return 0;
	if((*lst).inicio->city.id == id){
		p = (*lst).inicio;
		(*lst).inicio = p->prox;
		(*lst).inicio->ant = NULL;
		free(p);
	}
	else if((*lst).fim->city.id == id){
		p = (*lst).fim;
		(*lst).fim = p->ant;
		(*lst).fim->prox = NULL;
		free(p);
	}
	else{
		p = (*lst).inicio->prox;
		while(p->city.id!=id && p!=(*lst).fim)
			p = p->prox;
		if(p->city.id==id){
			p->ant->prox = p->prox;
			p->prox->ant = p->ant;
			free(p);
		}
		else
			return -1;
	}
	return 1;
}
int lista_vazia( Descritor *lst){
	return (*lst).qtde == 0;
}
int tamanho_lista( Descritor *lst){
	return (*lst).qtde;
}
int imprimir_lista( Descritor *lst){
	Elem *p = (*lst).inicio;
	if((*lst).qtde == 0)
		return 0;
	while(p!=NULL){
		escrever_cidade(p->city);
		p = p->prox;
	}
		
	return 1;
}
void destruir_lista( Descritor *lst){
	Elem *p , *no = (*lst).inicio;
	
	while(no!=NULL){
		p = no;
		no = p->prox;
		free(p);
	}
	(*lst).inicio=NULL;
	(*lst).fim=NULL;
	(*lst).qtde=0;
}

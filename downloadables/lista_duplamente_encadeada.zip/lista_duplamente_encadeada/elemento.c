#include <stdlib.h>
#include "elemento.h"

Elem *alocar_elem(void){
	return (Elem *) malloc(sizeof(Elem));
}

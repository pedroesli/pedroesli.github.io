#ifndef CIDADE_H
#define CIDADE_H
#define TAMANHO_NOME_CIDADE 30

typedef struct cidade {
  int id;
  char nome[TAMANHO_NOME_CIDADE];
  char uf[3];
  int populacao;
} Cidade;

/* Retorna uma struct cidade com os valores lidos pelo teclado. */
Cidade ler_cidade(void);

/* Imprime na tela os campos de uma cidade recebida como parametro */
void escrever_cidade(Cidade city);
#endif // CIDADE_H

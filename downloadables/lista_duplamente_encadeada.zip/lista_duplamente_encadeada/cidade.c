/*
 * cidade.c
 *
 *
 * Created by José Adalberto F. Gualeve  on 13/3/2019.
 * Copyright 2019 - All rights reserved
 *
 */
#include <stdio.h>

#include "cidade.h"

Cidade ler_cidade()
{
  Cidade city;
  printf("Identificador da Cidade: ");
  scanf("%d", &city.id);
  /* Usar fflush no windows */
  fflush(stdin);  
  printf("Nome da Cidade: ");
  gets(city.nome);
  printf("Unidade da Federacao: ");
  fflush(stdin);
  gets(city.uf);
  printf("Populacao: ");
  scanf("%d", &city.populacao);
  return city;
}

void escrever_cidade(Cidade city)
{
  printf("%10d : ", city.id);
  printf("%-30s : ", city.nome);
  printf("%3s : ", city.uf);
  printf("%10d\n", city.populacao);
  return;
}
